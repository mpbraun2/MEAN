#Deck of Cards Outline

##Object constructors with properties/methods

+ **Deck**
  + cards
  + shuffle
  + reset
  + dealRandomCard
+ **Card**
  + value
  + suit
+ **Player**
  + name
  + hand
  + takeCard
  + discard